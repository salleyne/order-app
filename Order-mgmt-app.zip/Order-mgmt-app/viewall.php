<?php
	//Database Connection
	include 'connect.php';
	
	//Define how many orders per page
	$pageResults = 10;
	
	//Query to get records from the database
	$sql = "SELECT * FROM ordertb";
	$result = $conn->query($sql);
	
	//Find out the number of orders in the database
	$numResults = $result->num_rows;
	
	//Header for page
	echo "<h2 align='center' style='font-family:Arial; font-size:24px'>Order Management</h2>";

	//Determine number of total pages available
	$numPages = ceil($numResults/$pageResults);
				
	//Determine which page number user is on
	if(!isset($_GET['page']))
	{
		$page = 1;
	}
	else
	{
		$page = $_GET['page'];	
	}
	
	//Determine the sql LIMIT starting number for the results on the displaying page
	$thisPage = ($page - 1)*$pageResults;
		
	//Retrieve selected results from database and display them on page
	$thisresult = $conn->query("SELECT * FROM ordertb LIMIT " .$thisPage.','.$pageResults);
	
		
	 //Return to homepage button
	echo "<button onClick=\"goBack()\"><< Home</button>";
	echo "<script language='javascript' type='text/javascript'>";
		echo "function goBack(){window.history.back();}";
	echo "</script>";

	echo "<fieldset>";
	  echo "<legend>All Orders</legend>";
	  echo "<table border='1' bordercolor='black' style='width:100%'>";
	  	echo "<tr><th>User</th><th>Product</th><th>Price</th><th>Quantity</th><th>Discount</th><th>Total</th><th>Date</th><th>Actions</th></tr>";
		while($row = $thisresult->fetch_assoc())
		{
			$id = $row['userID'];
			$order = $row['orderID'];
			$user = $conn->query("SELECT username FROM user WHERE userID = '$id'")->fetch_object()->username;
			
			//Display Discount
			$discount = "0%";
			$prod = $row['orderDesc'];
			$quantity = $row["orderQuantity"];
			if ($prod=="Pepsi Cola" && $quantity>=3)
			{
				$discount = "20%";
			}
			
				echo "<tr><td align='center'>$user</td><td align='center'>".$row["orderDesc"]."</td><td align='center'>$".$row["orderSubTotal"]."</td><td align='center'>".$row["orderQuantity"]."</td><td align='center'>$discount</td><td align='center'>$".$row["orderTotal"]."</td><td align='center'>".$row["orderDate"]."</td><td align='center'><a href='edit.php?orderid=$order' alt='Edit'>Edit </a>&nbsp; &nbsp;<a onClick=\"javascript: return confirm('Please confirm deletion');\" href='delete.php?orderid=$order' alt='Delete'> Delete</a></td></tr>";
		}
		  echo "</table>";
	echo "</fieldset>";
		//Display links to the pages
		for($page=1;$page<=$numPages;$page++)
		{
			echo '<a  href="viewall.php?page=' . $page . '">' . $page . "    ". '</a>';
		}
	//}

?>