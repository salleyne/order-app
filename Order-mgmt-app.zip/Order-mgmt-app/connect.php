<?php
    //Check Connection
	$conn = new mysqli("localhost","root","","dborder"); 
	
	//Output any connection error
	if (!$conn) { 
		die("Error: ". $conn->connect_error);
	}
?>