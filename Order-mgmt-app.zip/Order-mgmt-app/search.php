<?php
	//Database Connection
	include 'connect.php';
	
	//Assign data entered in textbox to variable
	if(isset($_GET['searchUser']))
	{
		$txtInfo = $_GET['searchUser'];
	}
	else
	{
		echo "No information supplied";
		
	}
		
	function test($conn,$result,$count)
	{
		//Return to homepage button
		echo "<button onClick=\"goBack()\"><< Home</button>";
		echo "<script language='javascript' type='text/javascript'>";
			echo "function goBack(){window.history.back();}";
		echo "</script>";
		echo  "<br/>";	
	  
	  	//Display order results
		echo "<fieldset>";
	  	echo "<legend>Product Orders</legend>";
	    	echo "<table border='1' bordercolor='black' style='width:100%'>";
			
			echo "<tr><th>User</th><th>Product</th><th>Price</th><th>Quantity</th><th>Discount</th><th>Total</th><th>Date</th></tr>";
			while($row = $result->fetch_assoc())
			{
				if($count == 0)
				{ 
					$id = $row['userID'];
		  			$user = $conn->query("SELECT username FROM user WHERE userid = '$id'")->fetch_object()->username;
				}
				else
				{
					$user = $row["username"];
				}
				
				$discount = "0%";
				$prod = $row['orderDesc'];
				$quantity = $row["orderQuantity"];
				if ($prod=="Pepsi Cola" && $quantity>=3)
				{
					$discount = "20%";
				}
				echo "<tr><td align='center'>$user</td><td align='center'>".$row["orderDesc"]."</td><td align='center'>$".$row["orderSubTotal"]."</td><td align='center'>".$row["orderQuantity"]."</td><td align='center'>$discount</td><td align='center'>$".$row["orderTotal"]."</td><td align='center'>".$row["orderDate"]."</td></tr>";
			}
			echo "</table>";
	   echo "</fieldset>";	
	   
	}

		
	echo "<h2 align='center' style='font-family:Arial; font-size:24px'>Order Management</h2>";
	//Test if textbox is empty
	if(!empty($txtInfo))
	{
		//Query database for all orders of product entered in textbox
		$result = $conn->query("SELECT * FROM ordertb WHERE orderDesc = '$txtInfo' ORDER BY orderDate DESC");
						
		//Displays results on page
		if($result->num_rows > 0)
		{
		  $count = 0;
		  test($conn,$result,$count);
		}//end of IF for orderDesc
		else
		{
			//Query database for orderid associated with username entered in textbox
			$id = $conn->query("SELECT userid FROM user WHERE username = '$txtInfo'")->fetch_object()->userid;
			  
		   //Query database for all orders associated with the username
		   $result = $conn->query("SELECT user.username, ordertb.orderDesc, ordertb.orderSubTotal, ordertb.orderQuantity, ordertb.orderTotal, ordertb.orderDate FROM user INNER JOIN ordertb ON user.userid = '$id'");

		  //Display results on pasge
		  if($result->num_rows > 0)
		  {
			  $count = 1;
			  test($conn,$result,$count);
		  }
		  else
		  {
			//Displays message if no orders match
		    echo "No records found";
		  }
		}//end of else for orderDesc
	}//end of IF for textbox validation
	else//else when textbox is empty
	{
		//Assign option selected in dropdown menu to variable
		$show = $_GET['search'];
		
		//Test selecton from menu
		switch ($show)
		{
			//IF TODAY IS SELECTED
			case "Today":
			//Get today's date
			$day = date("Y-m-d");
			
			//Query order date from database
			$today = $conn->query("SELECT * FROM ordertb WHERE DATE(orderDate) = '".$day."'");
			
			//Display all associated orders
			if($today->num_rows > 0)
			{
				$count = 0;
				test($conn,$today,$count);
			}//end If
			else
			{
				//Displays message if no orders are found
				echo "0 records found";	
			}
			break;
				
			//IF 7 DAYS IS SELECTED
			case "7 Days":
			//Query database for all records for the last 7 days
			$today = $conn->query("SELECT * FROM ordertb WHERE orderDate > DATE_SUB(NOW(), INTERVAL 7 DAY)ORDER BY orderDate DESC");
			
			//Display all associated orders
			if($today->num_rows > 0)
			{
				$count = 0;
				test($conn,$today,$count);
			}
			else
			{
				//Displays message if no orders are found
				echo "0 records found";	
			}
			break;
				
			//IF ALL TIME IS SELECTED
			case "All time":
			//Query database for all records
			$result = $conn->query("SELECT * FROM ordertb ORDER BY orderDate DESC");
				
			//Display all orders
			if ($result->num_rows > 0)
			{
				$count = 0;
				test($conn,$result,$count);
			}
			else
			{
				//Displays message if no orders are found
				echo "0 results";	
			}
			break;
		}//end of Switch
	}//end of else
	
	//Close Database Connection
		$conn->close();
?>