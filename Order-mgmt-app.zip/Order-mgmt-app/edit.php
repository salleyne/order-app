<?php
	//Database Connection
	include 'connect.php';
	
	//Get ID from database
	if(isset($_GET['orderid']))
	{
		$sql = "SELECT * FROM ordertb WHERE orderID =".$_GET['orderid'];
		$result = mysqli_query($conn,$sql);
		$row = mysqli_fetch_array($result);
		$id = $row['userID'];
		$nm = $conn->query("SELECT username FROM user WHERE userid = '$id'")->fetch_object()->username;
	}
	
	//Update Information
	if(isset($_POST['btnUpdate']))
	{
		$quantity = $_POST['num'];
		$prod = $_POST['item'];
		$cost = (float) $conn->query("SELECT productCost FROM product WHERE productname = '$prod'")->fetch_object()->productCost;
		$discount = 0;
		
		if ($prod=="Pepsi Cola" && $quantity>=3){
			$discount = (float) 0.80;
			$cost = (float)$quantity*$cost;
			$total = (float)$cost*$discount;
		}
		else
		{
			$total = (float)$quantity*$cost;	
		}
		
		//Updated information added to database
		$update = "UPDATE ordertb SET orderQuantity = '$quantity', orderDesc = '$prod', orderSubTotal = '$cost', orderDiscount = '$discount', orderTotal = '$total' WHERE orderID =".$_GET['orderid'];
		$info = mysqli_query($conn,$update);
				
		if(!isset($sql))
		{
			die("Error $sql" .mysqli_connect_error());
		}
		else
		{
			//Return to homepage
			header("Location: index.php");	
		}
	}
?>

<!--Create Edit page-->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit Information</title>
</head>

<body>
	<h2 align="center" style="font-family:Arial; font-size:24px"> Order Management</h2>
	<form method="post">
    	<fieldset>
    		<legend>Edit Order</legend>
            <table border='1' bordercolor='black' style='width:100%'>
            	<tr><th>User</th><th>Product</th><th>Price</th><th>Quantity</th><th>Discount</th><th>Total</th><th>Date</th></tr>
             	 <tr><td align='center'><?php echo $nm;?></td><td align='center'><select name="item" id="item"><option>Pepsi Cola</option><option>Sprite</option><option>Fanta</option></select></td><td align='center'><?php echo $row['orderSubTotal'];?></td><td align='center'>        	<select name="num" id="num"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select></td></td><td align='center'><?php if ($row['orderDiscount']=="0.80"){echo "20%";}else{echo "0%";}?></td><td align='center'><?php echo $row['orderTotal'];?></td><td align='center'><?php echo $row['orderDate'];?></td></tr>
             </table>
             <br> <br>
             <button type="submit" name="btnUpdate" id="btnUpdate" onClick="update()">Update Record</button>
             <a href="index.php"><button type="button" value="button">Cancel</button></a>
        </fieldset>
    </form>
    
    <!--Alert for updating -->
    <script>
		function update()
		{
			var x;
			if(confirm("Updated Data Successfully")==true)
			{
				x = "update";
			}
		}
	</script>
</body>
</html>