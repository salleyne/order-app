<?php
    date_default_timezone_set('America/Barbados');
	//Database Connection
	include 'connect.php';
				
	//Post inputs from index.php
	$nm=$_POST['user'];
	$prod=$_POST['item'];
	$quantity=$_POST['num'];
		
	//Get associated user id where username equals name from dropdown list
	$result = $conn->query("SELECT userid FROM user WHERE username = '$nm'")->fetch_object()->userid;
		
	//Get associated cost of product
	$cost = (float) $conn->query("SELECT productCost FROM product WHERE productname = '$prod'")->fetch_object()->productCost;
		
    //Set discount default
	$discount = 0;
	$showDis = "0%";
		
	//Apply discount if product and quantity meet the criteria
	if ($prod=="Pepsi Cola" && $quantity>=3){		
	    $discount = (float) 0.80;
		$showDis = "20%";
			
		//Calculate cost of product
		$cost = (float)$quantity*$cost;
			
		//Calculate cost of product with discount applied
		$total = (float)$cost*$discount;
	} else {
		//Calculate cost of product without discount applied
		$total = (float)$quantity*$cost;
	}
		
	//Insert order into the Database
	$sql = "INSERT INTO ordertb (productID,userid,orderDesc,orderQuantity,orderSubTotal,orderDiscount,orderTotal) VALUES ((SELECT product.productID FROM product WHERE productname = '$prod'),'$result','$prod','$quantity','$cost','$discount','$total')";
		
	if ($conn->query($sql)===TRUE){ 
        $last_id = $conn->insert_id;
	} else {
	    echo "Error: " . mysqli_connect_error();
	}
	
	$link = '#';
		
	//Set date format
	$day = date("Y-m-d h:ia");
	echo "<h2 align='center' style='font-family:Arial; font-size:24px'> Order Management</h2>";
		
	//Return to homepage button
	echo "<button onClick=\"goBack()\"><< Home</button>";
	echo "<script language='javascript' type='text/javascript'>";
		echo "function goBack(){window.history.back();}";
	echo "</script>";
		
	//Display newly created order on page with option to Edit or Delete
	echo "<fieldset>";
	     echo "<legend>Order Summary</legend>";
		 echo "<table border='1' bordercolor='black' style='width:100%'>";
			echo "<tr>
					<th>User</th>
					<th>Product</th>
					<th>Price</th>
					<th>Quantity</th>
					<th>Discount</th>
					<th>Total</th>
					<th>Date</th>
					<th>Actions</th>
				   </tr>";
			echo "<tr>
					<td align='center'>$nm</td>
					<td align='center'>$prod</td>
					<td align='center'>$ $cost.00</td>
					<td align='center'>$quantity</td>
					<td align='center'>$showDis</td>
					<td align='center'>$ $total.00</td>
					<td align='center'>$day</td>
					<td align='center'><a href='edit.php?orderid=$last_id' alt='Edit'>Edit </a>
					&nbsp; &nbsp;
					<a onClick=\"javascript: return confirm('Please confirm deletion');\" href='delete.php?orderid=$last_id' alt='Delete'> Delete</a></td>
				  </tr>";
		 echo "</table>";
	echo "</fieldset>";
?>