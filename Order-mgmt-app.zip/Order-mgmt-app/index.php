<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Order Management App</title>
</head>

<body>
    <h2 align="center" style="font-family:Arial; font-size:24px"> Order Management</h2>
	<div align="center">
     <form name="frmOrder" method="post" action="add.php" enctype="multipart/form-data">
   		<fieldset style="display:inline-block" >
    		<legend>Add New Order</legend>
        	<label for="name">Username</label>
        	<select name="user" id="user">
        		<option>Jane Doe</option>
          		<option>John Doe</option>
			   	<option>Lisa Smith</option>
        	</select>
            <br /><br />
       		<label for="product">Product</label>
       		<select name="item" id="item">
        		<option>Pepsi Cola</option>
	            <option>Sprite</option>
            	<option>Fanta</option>
        	</select>
            <br /><br />
        	<label for="amt">Quantity</label>
        	<select name="num" id="num">
        		<option>1</option>
            	<option>2</option>
            	<option>3</option>
            	<option>4</option>
            	<option>5</option>
        	</select>
            <br /><br />
            <input name="add" id="btnAdd" type="submit" value="Add" />
          </fieldset>
        <br /><br />
       </form>
  </div>
       
  <div align="center">
    <form name="searchView" method="get" action="search.php" enctype="multipart/form-data">
       <fieldset style="display:inline-block">
        	<legend>Search</legend>
        	<label for="find">Search</label>
        	<select name="search" id="search">
        		<option>Today</option>
            	<option>7 Days</option>
            	<option>All time</option>
        	</select>
            &nbsp; OR &nbsp;
        	<input name="searchUser" type="text" size="20px" placeholder="Enter search term..." />
            <br /><br />
            <input type="submit" name="btnSearch" value="Search" />        	
        </fieldset>
        <br /><br />
        
        <fieldset  style="display:inline-block">
        	<legend>View All Records</legend>
            <a href="viewall.php"><button type="button" value="button">Show All Records</button></a>
        </fieldset>
 
    </form>
  </div>
</body>
</html>