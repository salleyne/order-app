<?php
	//Database Connection
	include 'connect.php';
	
	//Get ID from database
	if(isset($_GET['orderid']))
	{
		$row = $_GET['orderid'];
		mysqli_query($conn,"DELETE FROM ordertb WHERE orderID = '$row'");
		
		header("Location: index.php");
	}
?>
